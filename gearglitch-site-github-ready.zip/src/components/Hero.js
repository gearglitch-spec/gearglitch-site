import React from 'react';

const Hero = () => (
  <section style={{ padding: '2rem', background: '#1a1a1a', color: 'white' }}>
    <h1>GearGlitch</h1>
    <p>Adventure Gear Meets Gaming Edge</p>
    <button>Shop Now</button>
    <button>Book Coaching</button>
  </section>
);

export default Hero;
