import React from 'react';

const Product = () => (
  <section style={{ padding: '2rem' }}>
    <h2>Survivor’s Edge – 14-in-1 Outdoor Kit</h2>
    <p>The ultimate companion for gamers who thrive outdoors.</p>
    <button>Buy Now</button>
  </section>
);

export default Product;
