import React from 'react';

const Coaching = () => (
  <section style={{ padding: '2rem', background: '#f0f0f0' }}>
    <h2>Coaching</h2>
    <p>1-on-1 sessions for outdoor survival or competitive gaming.</p>
    <a href="https://calendly.com/">Book a Session</a>
  </section>
);

export default Coaching;
