import React from 'react';

const Footer = () => (
  <footer style={{ padding: '1rem', background: '#333', color: 'white', textAlign: 'center' }}>
    © 2025 GearGlitch. All rights reserved.
  </footer>
);

export default Footer;
