import React from 'react';
import Hero from './components/Hero';
import Product from './components/Product';
import Coaching from './components/Coaching';
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Hero />
      <Product />
      <Coaching />
      <Footer />
    </div>
  );
}

export default App;
