# GearGlitch Site

React site for GearGlitch, ready for GitHub Pages deployment.